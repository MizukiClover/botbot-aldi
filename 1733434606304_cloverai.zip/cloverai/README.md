# YanzBotz-MD

Script Base WhatsApp Bot Multi Device

## NOTE

This Script is for everyone, not for Sale. Jika dijual neraka menunggumu brother !

<p align="center">
	<img src="https://telegra.ph/file/bea650da4df4831add817.jpg" width="35%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<h1 align="center">YanzBotz-MD</h1>

This is Script of WhatsApp multi device, working with [`@adiwajshing/baileys`](https://github.com/adiwajshing/baileys)

## UNTUK PENGGUNA WINDOWS/RDP

- Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
- Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
- Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)

```bash
git clone https://github.com/YanzBotz/YanzBotz-MD
cd YanzBotz-MD
npm install
```

## FOR TERMUX/UBUNTU/SSH USER

```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
git clone https://github.com/YanzBotz/YanzBotz-MD
cd YanzBotz-MD
npm install
```

## PAIRING-CODE

```bash
cd YanzBotz-MD
node index.js --pairing-code
```

## RECOMMENDED INSTALL ON TERMUX

```bash
pkg install yarn
yarn
```

## Installing

```bash
$ node .
```

## ❗ Warning

WhatsApp bot is still in the development stage, so there are a few bugs
WhatsApp Connection (BETA, not working perfectly)

Editing Number Owner & session name in [`config.js`](https://github.com/YanzBotz/YanzBotz-MD/blob/main/lib/validator/config.js)
My Apikey [`YanzBotz-APIs`](https://api.yanzbotz.my.id)

## Thanks To

- [`@adiwajshing/baileys`](https://github.com/adiwajshing/baileys)
- [`YanzBotz`](https://github.com/YanzBotz)
- [`Febriansyah`](https://github.com/FebriansyahXd)
- [`Arasya`](https://github.com/GetSya)
- [`DikaArdnt`](https://github.com/DikaArdnt)
- [`Rifza.p.p`](https://github.com/Rifza123)
- [`Imam mahdi`](http://github.com/Adi-OfficialL)
- [`Zansky`](http://github.com/myname31)
- [`IqbalzzX`](http://github.com/IqbalzzX)
- [`Ridho Atak`](https://github.com/atak676)
- [`Nathaniel`](https://github.com/natgvlite)
- [`Aprilia`](https://github.com/ALDI33)
- [`Aldi Fauzi`](https://github.com/ALDI33)

License: [MIT](https://en.wikipedia.org/wiki/MIT_License)

Support Me

- [`Saweria`](https://saweria.co/YanzBotzX)
