const SETTING = require("../lib/validator/config");
const keywords = require("../lib/validator/allKeywords");
//=======================================================//
/* { module } */
//=======================================================//
let modul = SETTING["modul"];
let getreq = SETTING["file"];
const chalk = modul["chalk"];
const fs = modul["fs"];
const util = modul["util"];
const https = modul["https"];
const axios = modul["axios"];
const { spawn, exec, execSync } = modul["child"];
const {
  downloadContentFromMessage,
  WA_DEFAULT_EPHEMERAL,
  getLastMessageInChat,
  MessageType,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  proto,
} = modul["baileys"];
const moment = modul["time"];
const time = moment.tz("Asia/Jakarta").format("DD/MM HH:mm:ss");
const qrcode = modul["qrcode"];
const QrCode = modul["QrCode"];
const qr = new QrCode();
const { sizeFormatter } = modul["sizeFormater"];
const speed = modul["speed"];
const request = modul["request"];
const path = modul["path"];
const ms = modul["premium"];

/*<--------------------( external function )--------------------->*/
const { tmpFile } = require("." + getreq["upload"]);
const { clover } = require("." + getreq["clover"]);
const { color, bgcolor, ConsoleLog, biocolor } = require("." + getreq["color"]);
const {
  reSize,
  runtime,
  getBuffer,
  getRandom,
  pickRandom,
  fetchJson,
  isUrl,
  genMath,
  formatp,
} = require("." + getreq["funct"]);
const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid,
  writeExif,
  writeExifStc,
} = require("." + getreq["exif"]);

/*<--------------------( JSON )--------------------->*/


/*<--------------------( Media )--------------------->*/

const thumb = fs.readFileSync(getreq["thumb"]);

/*<--------------------( Exports this function )--------------------->*/

module.exports = async (msg, client, from, store) => {
  /*<--------------------( Detect )--------------------->*/

  const isGrouP = msg.key.remoteJid.endsWith("@g.us");
  const sender = isGrouP
    ? msg.key.participant
      ? msg.key.participant
      : msg.participant
    : msg.key.remoteJid;
  const pushname = msg.pushName || "No Name";
  const CMD =
    msg.xtype === "conversation" && msg.message.conversation
      ? msg.message.conversation
      : msg.xtype == "imageMessage" && msg.message.imageMessage.caption
        ? msg.message.imageMessage.caption
        : msg.xtype == "videoMessage" && msg.message.videoMessage.caption
          ? msg.message.videoMessage.caption
          : msg.xtype == "extendedTextMessage" &&
              msg.message.extendedTextMessage.text
            ? msg.message.extendedTextMessage.text
            : msg.xtype == "buttonsResponseMessage" &&
                msg.message.buttonsResponseMessage.selectedButtonId
              ? msg.message.buttonsResponseMessage.selectedButtonId
              : msg.xtype == "listResponseMessage" &&
                  msg.message.listResponseMessage.singleSelectReply
                    .selectedRowId
                ? msg.message.listResponseMessage.singleSelectReply
                    .selectedRowId
                : msg.xtype == "templateButtonReplyMessage" &&
                    msg.message.templateButtonReplyMessage.selectedId
                  ? msg.message.templateButtonReplyMessage.selectedId
                  : "".slice(1).trim().split(/ +/).shift().toLowerCase();
  const prefix = /^[#!.,®©¥€¢£/\∆✓]/.test(CMD)
    ? CMD.match(/^[#!.,®©¥€¢£/\∆✓]/gi)
    : "#";
  global.prefix = prefix;
  const chatmessage =
    msg.xtype === "conversation" && msg.message.conversation
      ? msg.message.conversation
      : msg.xtype == "imageMessage"
        ? msg.message.imageMessage.caption
        : msg.xtype == "videoMessage"
          ? msg.message.videoMessage.caption
          : msg.xtype == "extendedTextMessage"
            ? msg.message.extendedTextMessage.text
            : msg.xtype == "buttonsResponseMessage"
              ? msg.message.buttonsResponseMessage.selectedButtonId
              : msg.xtype == "listResponseMessage"
                ? msg.message.listResponseMessage.singleSelectReply
                    .selectedRowId
                : msg.xtype == "templateButtonReplyMessage"
                  ? msg.message.templateButtonReplyMessage.selectedId
                  : msg.xtype === "messageContextInfo"
                    ? msg.message.buttonsResponseMessage?.selectedButtonId ||
                      msg.message.listResponseMessage?.singleSelectReply
                        .selectedRowId ||
                      msg.text
                    : "";
  const ordermessage =
    msg.xtype === "conversation" && msg.message.conversation
      ? msg.message.conversation
      : msg.xtype == "imageMessage" && msg.message.imageMessage.caption
        ? msg.message.imageMessage.caption
        : msg.xtype == "videoMessage" && msg.message.videoMessage.caption
          ? msg.message.videoMessage.caption
          : msg.xtype == "extendedTextMessage" &&
              msg.message.extendedTextMessage.text.startsWith(prefix)
            ? msg.message.extendedTextMessage.text
            : msg.xtype == "buttonsResponseMessage" &&
                msg.message.buttonsResponseMessage.selectedButtonId.startsWith(
                  prefix,
                )
              ? msg.message.buttonsResponseMessage.selectedButtonId
              : msg.xtype == "listResponseMessage" &&
                  msg.message.listResponseMessage.singleSelectReply.selectedRowId.startsWith(
                    prefix,
                  )
                ? msg.message.listResponseMessage.singleSelectReply
                    .selectedRowId
                : msg.xtype == "templateButtonReplyMessage" &&
                    msg.message.templateButtonReplyMessage.selectedId.startsWith(
                      prefix,
                    )
                  ? msg.message.templateButtonReplyMessage.selectedId
                  : "";
  const chats =
    msg.xtype === "conversation" && msg.message.conversation
      ? msg.message.conversation
      : msg.xtype == "imageMessage" && msg.message.imageMessage.caption
        ? msg.message.imageMessage.caption
        : msg.xtype == "documentMessage" && msg.message.documentMessage.caption
          ? msg.message.documentMessage.caption
          : msg.xtype == "videoMessage" && msg.message.videoMessage.caption
            ? msg.message.videoMessage.caption
            : msg.xtype == "extendedTextMessage" &&
                msg.message.extendedTextMessage.text
              ? msg.message.extendedTextMessage.text
              : msg.xtype == "buttonsResponseMessage" &&
                  msg.message.buttonsResponseMessage.selectedButtonId
                ? msg.message.buttonsResponseMessage.selectedButtonId
                : msg.xtype == "templateButtonReplyMessage" &&
                    msg.message.templateButtonReplyMessage.selectedId
                  ? msg.message.templateButtonReplyMessage.selectedId
                  : "";
  const args = ordermessage.trim().split(/ +/).slice(1);
  const order = ordermessage.slice(0).trim().split(/ +/).shift().toLowerCase();
  const command = ordermessage.slice(1);
  const q = args.join(" ");
  const fatkuns = msg.quoted || msg;
  const quoted =
    fatkuns.xtyp == "buttonsMessage"
      ? fatkuns[Object.keys(fatkuns)[1]]
      : fatkuns.xtyp == "templateMessage"
        ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]]
        : fatkuns.xtyp == "product"
          ? fatkuns[Object.keys(fatkuns)[0]]
          : msg.quoted
            ? msg.quoted
            : msg;
  const isCmd = ordermessage.startsWith(prefix);
  const content = JSON.stringify(msg.message);
  const orderPlugins = isCmd
    ? ordermessage.slice(1).trim().split(/ +/).shift().toLowerCase()
    : null;
  const isGroup = from.endsWith(keywords[0]["chats"][1]);
  const botNumber = client.user.id.split(":")[0] + keywords[0]["chats"][0];
  const mime = (quoted.msg || quoted).mimetype || "";
  const isMedia = /image|video|sticker|audio/.test(mime);
  const itulho = isGroup
    ? msg.key.participant
      ? msg.key.participant
      : msg.participant
    : msg.key.remoteJid;
  const isOwner = [botNumber, ...global.ownerNumber]
    .map((jid) => jid.replace(/[^0-9]/g, "") + keywords[0]["chats"][0])
    .includes(itulho);
  const groupMetdata = isGroup ? await client.groupMetadata(from) : "";
  client.groupMembers = isGroup ? groupMetdata.participants : "";
  client.groupName = isGroup ? await groupMetdata.subject : "";
  client.groupAdmins = isGroup ? msg.getGroupAdmins(client.groupMembers) : "";
  const isBotGroupAdmins = client.groupAdmins.includes(botNumber) || false;
  const isGroupAdmins = client.groupAdmins.includes(msg.sender);

  /*<--------------------( Participant mentions )--------------------->*/

  const mentionByTag =
    msg.xtype == "extendedTextMessage" &&
    msg.message.extendedTextMessage.contextInfo != null
      ? msg.message.extendedTextMessage.contextInfo.mentionedJid
      : [];
  const mentionByreply =
    msg.xtype == "extendedTextMessage" &&
    msg.message.extendedTextMessage.contextInfo != null
      ? msg.message.extendedTextMessage.contextInfo.participant || ""
      : "";
  const mention =
    typeof mentionByTag == "string" ? [mentionByTag] : mentionByTag;
  mention != undefined ? mention.push(mentionByreply) : [];
  const mentionUser = mention != undefined ? mention.filter((n) => n) : false;

  /*<--------------------( Plugins )--------------------->*/

  for (let name in plugins) {
    let plugin = plugins[name];
    if (plugin.order && plugin.order.includes(orderPlugins)) {
      let turn =
        plugin.order instanceof Array
          ? plugin.order.includes(orderPlugins)
          : plugin.order instanceof String
            ? plugin.order == orderPlugins
            : false;
      if (!turn) continue;
      if (plugin.owner && !isOwner) {
        msg.reply(keywords[0]["message"][2]);
        continue;
      }
      if (plugin.group && !isGroup) {
        msg.reply(keywords[0]["message"][1]);
        continue;
      }
      if (plugin.groupAdmins && !isGroupAdmins) {
        msg.reply(keywords[0]["message"][3]);
        continue;
      }
      if (plugin.botGroupAdmins && !isBotGroupAdmins) {
        msg.reply(keywords[0]["message"][4]);
        continue;
      }
      await plugin.exec(msg, client, from, { q, args, order });
    }
  }

  /*<--------------------( Function )--------------------->*/

  const sleep = async (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  };

  const today = moment().tz("Asia/Jakarta");
  const day = today.format("dddd");
  const datee = today.format("D");
  const month = today.format("MMMM");
  const year = today.format("YYYY");

  const formatSize = sizeFormatter({
    std: "JEDEC",
    decimalPlaces: "2",
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`,
  });

  const replyNtag = (teks) => {
    client.sendMessage(
      from,
      { text: teks, mentions: parseMention(teks) },
      { quoted: msg },
    );
  };

  const sendFile = async (from, url, caption, msg, men) => {
    let mime = "";
    let res = await axios.head(url);
    mime = res.headers["content-type"];
    if (mime.split("/")[1] === "gif") {
      return client.sendMessage(
        from,
        {
          video: await getBuffer(url),
          caption: caption,
          gifPlayback: true,
          mentions: men ? men : [],
        },
        { quoted: msg },
      );
    }
    let type = mime.split("/")[0] + "Message";
    if (mime.split("/")[0] === "image") {
      return client.sendMessage(
        from,
        {
          image: await getBuffer(url),
          caption: caption,
          mentions: men ? men : [],
        },
        { quoted: nay1 },
      );
    } else if (mime.split("/")[0] === "video") {
      return client.sendMessage(
        from,
        {
          video: await getBuffer(url),
          caption: caption,
          mentions: men ? men : [],
        },
        { quoted: msg },
      );
    } else if (mime.split("/")[0] === "audio") {
      return client.sendMessage(
        from,
        {
          audio: await getBuffer(url),
          caption: caption,
          mentions: men ? men : [],
          mimetype: "audio/mpeg",
        },
        { quoted: msg },
      );
    } else {
      return client.sendMessage(
        from,
        {
          document: await getBuffer(url),
          mimetype: mime,
          caption: caption,
          mentions: men ? men : [],
        },
        { quoted: msg },
      );
    }
  };

  function parseMention(text) {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(
      (v) => v[1] + "@s.whatsapp.net",
    );
  }

  function randomNomor(min, max = null) {
    if (max !== null) {
      min = Math.ceil(min);
      max = Math.floor(max);
      return Math.floor(Math.random() * (max - min + 1)) + min;
    } else {
      return Math.floor(Math.random() * min) + 1;
    }
  }

  const yanz = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      ...(from ? { remoteJid: "status@broadcast" } : {}),
    },
    message: {
      contactMessage: {
        displayName: `${msg.sayingtime + msg.timoji}\n☏User: ${pushname}`,
        vcard:
          "BEGIN:VCARD\n" +
          "VERSION:3.0\n" +
          `item1.TEL;waid=${sender.split("@")[0]}:+${sender.split("@")[0]}\n` +
          "item1.X-ABLabel:Ponsel\n" +
          "END:VCARD",
      },
    },
  };

  /*<--------------------( EVAL )--------------------->*/

  if (chatmessage.startsWith("<")) {
    if (!isOwner) return;
    if (!q) return msg.reply("Masukan Parameter Code!");
    let kode = chatmessage.trim().split(/ +/)[0];
    let teks;
    try {
      teks = await eval(
        `(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`,
      );
    } catch (e) {
      teks = e;
    } finally {
      await msg.reply(require("util").format(teks));
    }
  }

  if (chatmessage.startsWith("=>")) {
    if (!isOwner) return;
    function Return(sul) {
      sat = JSON.stringify(sul, null, 2);
      bang = util.format(sat);
      if (sat == undefined) {
        bang = util.format(sul);
      }
      return msg.reply(bang);
    }
    try {
      msg.reply(
        util.format(eval(`(async () => { ${chatmessage.slice(3)} })()`)),
      );
    } catch (e) {
      msg.reply(String(e));
    }
  }

  if (chatmessage.startsWith(">")) {
    if (!isOwner) return;
    try {
      let evaled = await eval(chatmessage.slice(2));
      if (typeof evaled !== "string") evaled = require("util").inspect(evaled);
      await msg.reply(evaled);
    } catch (err) {
      msg.reply(String(err));
    }
  }

  if (chatmessage.startsWith("$")) {
    if (!isOwner) return;
    exec(chatmessage.slice(2), (err, stdout) => {
      if (err)
        return client.sendMessage(from, { text: String(err) }, { quoted: msg });
      if (stdout) return msg.reply(stdout);
    });
  }

  /*<--------------------( CMD )--------------------->*/

  if (isCmd && !isGroup) {
    console.log(
      keywords[0]["cmd"][0],
      keywords[0]["cmd"][1],
      time,
      color(`#${command} [${args.length}]`, "gray"),
      "from",
      color(msg.pushName),
    );
  }
  if (isCmd && isGroup) {
    console.log(
      keywords[0]["cmd"][0],
      keywords[0]["cmd"][1],
      time,
      color(`#${command} [${args.length}]`, "gray"),
      "from",
      color(msg.pushName),
      "in",
      color(client.groupName, "orange"),
    );
  }

  if (msg.message) {
    client.readMessages([msg.key]);
  }

  /*<--------------------( CASE )--------------------->*/

  switch (order) {
    case prefix + ["remini"]:
    case prefix + ["hd"]:
    case prefix + ["enhance"]:
      {
        // if (!isOwner) return msg.reply('Fitur sedang maintenance, silahkan vote di di group pilih hd foto')
        if (!(msg.message.imageMessage || msg.isQuotedImage)) {
          return msg.reply("Reply image\nContoh: .enhance");
        }

        msg.reply("Tunggu beberapa menit...");

        // Pengecekan media gambar dan download
        if (msg.message.imageMessage || msg.isQuotedImage) {
          mediaType = "image";
          media = msg.message.imageMessage
            ? await client.downloadAndSaveMediaMessage(
                msg.message.imageMessage,
                mediaType,
              )
            : await client.downloadAndSaveMediaMessage(
                msg.message.extendedTextMessage.contextInfo.quotedMessage
                  .imageMessage,
                mediaType,
              );

          try {
            let tph = await TelegraPh(fs.readFileSync(media));
            let ranJ = getRandom(".jpg");
            let hasil = await remini(tph);
            await client.sendMessage(
              from,
              {
                document: hasil,
                fileName: ranJ,
                mimetype: "image/jpeg",
                caption: "Result",
              },
              { quoted: msg },
            );
          } catch (e) {
            console.log(e);
            msg.reply("Error abangku🔥🔥");
          }
        }
      }
      break;
      
      case prefix + ['play']:
    if (args.length === 0) {
        return msg.reply('Silakan masukkan judul lagu yang ingin dicari.');
    }
    const query = args.join(' '); 
    try {
        const response = await axios.get(`https://api.vreden.my.id/api/ytplaymp3?query=${encodeURIComponent(query)}`);
        console.log('API Response:', JSON.stringify(response.data));
        if (response.data.status === 200) {
            const songData = response.data.result;
            const audioUrl = songData.download.url;
            const thumbnailUrl = songData.metadata.thumbnail;
            const title = songData.metadata.title; 
            console.log('Audio URL:', audioUrl);
            console.log('Thumbnail URL:', thumbnailUrl);
            await client.sendMessage(from, { image: { url: thumbnailUrl, }, caption: `Judul: ${title}` });
            await client.sendMessage(from, { audio: { url: audioUrl }, mimetype: 'audio/mpeg', ptt: true });
        } else {
            msg.reply('Maaf, lagu tidak ditemukan.');
        }
    } catch (error) {
        console.error('Error occurred:', error);
        msg.reply('Maaf, terjadi kesalahan saat memproses permintaan. Silakan coba lagi nanti.');
    }
    break;
               case prefix + ['youtube']:
                 case prefix + ['yt'] :
    if (args.length === 0) {
        return msg.reply('Silakan masukkan judul video yang ingin dicari.');
    }
    const queryVid = args.join(' ');
    try {
        const response = await axios.get(`https://api.agatz.xyz/api/ytplayvid?message=${encodeURIComponent(queryVid)}`);
        if (response.data.status === 200) {
            const videoData = response.data.data;
            const videoUrl = videoData.downloadUrl;
            const videoBuffer = await fetch(videoUrl).then(res => res.buffer());
            await client.sendMessage(from, { video: videoBuffer, mimetype: 'video/mp4', caption: videoData.title });
        } else {
            msg.reply('Maaf, video tidak ditemukan.');
        }
    } catch (error) {
        console.error('Error occurred:', error);
        msg.reply('Maaf, terjadi kesalahan saat memproses permintaan. Silakan coba lagi nanti.');
    }
    break;
    
    case prefix + ['instagram']:
case prefix + ['ig']: {
    if (!q) return msg.reply(`Berikan Link\nContoh: ${command} link`);
    if (!isUrl(q)) return msg.reply(`Link tidak sesuai`);
    if (!q.includes('instagram.com')) return msg.reply(`Link tidak sesuai`);

    msg.reply('_Sedang mendownload..._');
    
    try {
        const data1 = await fetchJson(`https://api.yanzbotz.live/api/downloader/instagram?url=${q}&apiKey=cakapin`);
        const data = data1.result;
        
        for (let item of data) {
            if (item.type === "video") {
                client.sendMessage(from, { video: { url: item.url } }, { quoted: msg });
            } else if (item.type === "image") {
                client.sendMessage(from, { caption: 'Sukses, Follow Instagram: @yanzbotz_', image: { url: item.url } }, { quoted: msg });
            }
        }
    } catch (error) {
        msg.reply('ERROR. Postingan tidak tersedia');
    }
}
break;

case prefix + ['tiktok']:
case prefix + ['tt']:
case prefix + ['tiktokdl']:
case prefix + ['tiktokslide']:
case prefix + ['tiktoknowm']:
case prefix + ['tiktokvid']:
case prefix + ['ttdl']: {
    if (!q) return msg.reply('Link nya mana');

    try {
        const ressol = await fetchJson(`https://api.yanzbotz.live/api/downloader/tiktok?url=${q}&apiKey=${global.apikey}`);
        const data = ressol.result;
        
        let text = '[ TIKTOK DOWNLOAD ]\n\n';
        text += `Type: ${data.type}\n`;
        text += `Name: ${data.name}\n`;
        text += `Username: ${data.username}\n`;
        text += `Views: ${data.views}\n`;
        text += `Likes: ${data.likes}\n`;
        text += `Comments: ${data.comments}\n`;
        text += `Favorite: ${data.favorite}\n`;
        text += `Shares: ${data.shares}\n`;
        text += `Description: ${data.description}\n\n`;
        
        const proces = await client.sendMessage(from, { text: 'Media type: ' + data.type }, { quoted: msg });
        
        if (data.type === 'image') {
            await client.editMessage(from, proces.key.id, text + '*Please wait.....*');
            for (let i = 0; i < data.image.length; i++) {
                await client.sendMessage(from, { image: { url: data.image[i] }, caption: 'Image: ' + (i + 1) }, { quoted: msg });
            }
        } else if (data.type === 'video') {
            await client.sendMessage(from, { video: { url: data.video['no-watermark'] }, caption: text }, { quoted: msg });
        }
    } catch (error) {
        msg.reply('ERROR. Tidak dapat mengunduh video');
    }
}
break;

case prefix + ['mediafire']:
    if (args.length === 0) {
        return msg.reply('Silakan masukkan link Mediafire yang valid.');
    }
    const mediafireLink = args[0];
    if (mediafireLink.includes('mediafire.com')) {
        try {
            const response = await axios.get(`https://api.vreden.my.id/api/mediafiredl?url=${encodeURIComponent(mediafireLink)}`);
            if (response.data.status === 200) {
                const file = response.data.result[0]; // Mengambil data file dari respons
                await client.sendMessage(from, { document: { url: file.link }, mimetype: file.mime, fileName: file.nama });
            } else {
                msg.reply('Maaf, terjadi kesalahan dalam mengambil file Mediafire.');
            }
        } catch (error) {
            msg.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
        }
    } else {
        msg.reply('Silakan masukkan link Mediafire yang valid.');
    }
    break;

    /*<--------------------( AKHIR CASE )--------------------->*/

    default:

      /*<--------------------( CHATBOT )--------------------->*/

      if (!msg.isBaileys && !isCmd && !isGroup) {
        if (
          msg.message.imageMessage ||
          msg.isQuotedImage ||
          msg.message.videoMessage ||
          msg.isQuotedVideo
        ) {
          const { key } = await client.sendMessage(
            from,
            { text: "```Sedang mencari jawaban...```" },
            {
              quoted: {
                key: {
                  participant: "0@s.whatsapp.net",
                  remoteJid: "0@s.whatsapp.net",
                },
                message: {
                  conversation: "_YanzBotz Terverifikasi Oleh WhatsApp_",
                },
              },
            },
          );
          console.log(
            "->[\x1b[1;32mNew\x1b[1;37m]",
            color("Question From", "yellow"),
            color(msg.pushName, "lightblue"),
            `: "${msg.text || "Gambar/Video Apakah Ini?"}"`,
          );

          try {
            let media =
              msg.message.imageMessage || msg.isQuotedImage
                ? await client.downloadAndSaveMediaMessage(
                    msg.message.imageMessage ||
                      msg.message.extendedTextMessage.contextInfo.quotedMessage
                        .imageMessage,
                    "image",
                  )
                : await client.downloadAndSaveMediaMessage(
                    msg.message.videoMessage ||
                      msg.message.extendedTextMessage.contextInfo.quotedMessage
                        .videoMessage,
                    "video",
                  );

            const tph = await tmpFile(fs.readFileSync(media));
            console.log(tph);
            const big = await fetchJson(
              `https://api.yanzbotz.live/api/ai/gemini-image?url=${tph}&query=${msg.text || "Tolong jawab soal ini dengan benar dan tepat"}&apiKey=yanzdev`,
            );
            await client.sendMessage(from, { text: big.result, edit: key });
          } catch (e) {
            console.log(e);
            await client.sendMessage(from, {
              text: "Terjadi Kesalahan",
              edit: key,
            });
          }
        } else if (msg.message.audioMessage || msg.isQuotedAudio) {
          client.sendMessage(from, { react: { text: "🔍", key: msg.key } });
          try {
            let media;
            if (msg.message.audioMessage) {
              media = await client.downloadAndSaveMediaMessage(
                msg.message.audioMessage,
                "audio",
              );
            } else if (msg.isQuotedAudio) {
              media = await client.downloadAndSaveMediaMessage(
                msg.message.extendedTextMessage?.contextInfo.quotedMessage
                  .audioMessage,
                "audio",
              );
            }
            const tph = await tmpFile(fs.readFileSync(media));
            console.log(tph);
            let { result } = await fetchJson(
              "https://api.yanzbotz.live/api/tools/whisper?url=" +
                tph +
                "&apiKey=yanzdev",
            );
            console.log(
              "->[\x1b[1;32mNew\x1b[1;37m]",
              color("Question From", "yellow"),
              color(msg.pushName, "lightblue"),
              `: "${result}"`,
            );
            const big = await clover(
              result.trim(),
              "yanzgpt-revolution-25b-v3.0",
            );
            console.log(big);
            const ynz = big.choices[0].message.content
              .replace(/####/g, "")
              .replace(/###/g, "")
              .replace(/##/g, "")
              .replace(/\*\*/g, "*");
            await client.sendMessage(
              from,
              {
                audio: {
                  url:
                    "https://api.yanzbotz.live/api/tts/tts-multi?query=" +
                    encodeURIComponent(
                      ynz
                        .replace(/\[\d+\]/g, "")
                        .replace(/\[.*?\]/g, "")
                        .replace(/Citations:[\s\S]*/, "")
                        .replace(/```[\s\S]*?```/g, "")
                        .trim(),
                    ) +
                    "&apiKey=yanzdev",
                },
                ptt: true,
                mimetype: "audio/mp4",
              },
              { quoted: msg },
            );
            if (big.image) {
              try {
                client.sendMessage(from, {
                  react: { text: "🖼️", key: msg.key },
                });
                const buffer = Buffer.from(big.image, "base64");
                await client.sendMessage(
                  from,
                  {
                    image: buffer,
                    caption: "Image From Yanz-GPT",
                    mimetype: "image/jpeg",
                  },
                  { quoted: msg },
                );
              } catch (error) {
                console.log("Error mengirim gambar:", error);
              }
            }
            client.sendMessage(from, { react: { text: "✅️", key: msg.key } });
          } catch (e) {
            console.log(e);
            //await client.sendMessage(from, { text: yanz.result, edit: key });
          }
        } else if (
          msg.text ||
          (msg.message.extendedTextMessage &&
            msg.message.extendedTextMessage.contextInfo?.quotedMessage
              ?.conversation)
        ) {
          const { key } = await client.sendMessage(
            from,
            { text: "```Sedang mencari jawaban...```" },
            { quoted: msg },
          );
          if (!msg.text) return;
          let model = "yanzgpt-revolution-25b-v3.0"; // model default
          let queryText = msg.text.trim();

          let qWords = queryText.split(/\s+/);
          if (qWords[0].toLowerCase() === "pro") {
            model = "yanzgpt-legacy-72b-v3.0";
            qWords.shift();
            queryText = qWords.join(" ");
          } else if (qWords[0].toLowerCase() === "default") {
            model = "yanzgpt-revolution-25b-v3.0";
            qWords.shift();
            queryText = qWords.join(" ");
          }
          if (
            msg.message.extendedTextMessage?.contextInfo?.quotedMessage
              ?.conversation
          ) {
            queryText = `${msg.message.extendedTextMessage.contextInfo.quotedMessage.conversation}\n\n${queryText}`;
          }

          console.log(
            "->[\x1b[1;32mNew\x1b[1;37m]",
            color("Question From", "yellow"),
            color(msg.pushName, "lightblue"),
            `: "${queryText}"`,
          );
          client.sendPresenceUpdate("composing", from);

          try {
            const big = await clover(
              queryText.trim(),
              model,
            );
            const ynz = big.choices[0].message.content
              .replace(/####/g, "")
              .replace(/###/g, "")
              .replace(/##/g, "")
              .replace(/\*\*/g, "*");
            await client.sendMessage(from, { text: ynz, edit: key });
            if (big.image) {
              try {
                //await client.sendMessage(from, { text: ynz, edit: key });
                const buffer = Buffer.from(big.image, "base64");
                await client.sendMessage(
                  from,
                  {
                    image: buffer,
                    caption: "Image From Yanz-GPT",
                    mimetype: "image/jpeg",
                  },
                  { quoted: msg },
                );
              } catch (error) {
                console.log("Error mengirim gambar:", error);
              }
            }
          } catch (e) {
          	console.log(e);
            await client.sendMessage(from, {
              text: "Terjadi kesalahan",
              edit: key,
            });
          }
        }
      }
      
      /*<--------------------( TAG CHATBOT )--------------------->*/

      if (!msg.isBaileys && !isCmd && chatmessage.startsWith('@' + botNumber.split('@')[0])) {
        if (
          msg.message.imageMessage ||
          msg.isQuotedImage ||
          msg.message.videoMessage ||
          msg.isQuotedVideo
        ) {
          const { key } = await client.sendMessage(
            from,
            { text: "```Sedang mencari jawaban...```" },
            {
              quoted: {
                key: {
                  participant: "0@s.whatsapp.net",
                  remoteJid: "0@s.whatsapp.net",
                },
                message: {
                  conversation: "_YanzBotz Terverifikasi Oleh WhatsApp_",
                },
              },
            },
          );
          console.log(
            "->[\x1b[1;32mNew\x1b[1;37m]",
            color("Question From", "yellow"),
            color(msg.pushName, "lightblue"),
            `: "${msg.text || "Gambar/Video Apakah Ini?"}"`,
          );

          try {
            let media =
              msg.message.imageMessage || msg.isQuotedImage
                ? await client.downloadAndSaveMediaMessage(
                    msg.message.imageMessage ||
                      msg.message.extendedTextMessage.contextInfo.quotedMessage
                        .imageMessage,
                    "image",
                  )
                : await client.downloadAndSaveMediaMessage(
                    msg.message.videoMessage ||
                      msg.message.extendedTextMessage.contextInfo.quotedMessage
                        .videoMessage,
                    "video",
                  );

            const tph = await tmpFile(fs.readFileSync(media));
            console.log(tph);
            const big = await fetchJson(
              `https://api.yanzbotz.live/api/ai/gemini-image?url=${tph}&query=${msg.text.replace(/\${botNumber.split('@')[0]}/g, "").trim() || "Tolong jawab soal ini dengan benar dan tepat"}&apiKey=yanzdev`,
            );
            await client.sendMessage(from, { text: big.result, edit: key });
          } catch (e) {
            console.log(e);
            await client.sendMessage(from, {
              text: "Terjadi Kesalahan",
              edit: key,
            });
          }
        } else if (msg.message.audioMessage || msg.isQuotedAudio) {
          client.sendMessage(from, { react: { text: "🔍", key: msg.key } });
          try {
            let media;
            if (msg.message.audioMessage) {
              media = await client.downloadAndSaveMediaMessage(
                msg.message.audioMessage,
                "audio",
              );
            } else if (msg.isQuotedAudio) {
              media = await client.downloadAndSaveMediaMessage(
                msg.message.extendedTextMessage?.contextInfo.quotedMessage
                  .audioMessage,
                "audio",
              );
            }
            const tph = await tmpFile(fs.readFileSync(media));
            console.log(tph);
            let { result } = await fetchJson(
              "https://api.yanzbotz.live/api/tools/whisper?url=" +
                tph +
                "&apiKey=yanzdev",
            );
            console.log(
              "->[\x1b[1;32mNew\x1b[1;37m]",
              color("Question From", "yellow"),
              color(msg.pushName, "lightblue"),
              `: "${result}"`,
            );
            const big = await clover(
              result.replace(/\${botNumber.split('@')[0]}/g, "").trim(),
              "yanzgpt-revolution-25b-v3.0",
            );
            console.log(big);
            const ynz = big.choices[0].message.content
              .replace(/####/g, "")
              .replace(/###/g, "")
              .replace(/##/g, "")
              .replace(/\*\*/g, "*");
            await client.sendMessage(
              from,
              {
                audio: {
                  url:
                    "https://api.yanzbotz.live/api/tts/tts-multi?query=" +
                    encodeURIComponent(
                      ynz
                        .replace(/\[\d+\]/g, "")
                        .replace(/\[.*?\]/g, "")
                        .replace(/Citations:[\s\S]*/, "")
                        .replace(/```[\s\S]*?```/g, "")
                        .trim(),
                    ) +
                    "&apiKey=yanzdev",
                },
                ptt: true,
                mimetype: "audio/mp4",
              },
              { quoted: msg },
            );
            if (big.image) {
              try {
                client.sendMessage(from, {
                  react: { text: "🖼️", key: msg.key },
                });
                const buffer = Buffer.from(big.image, "base64");
                await client.sendMessage(
                  from,
                  {
                    image: buffer,
                    caption: "Image From Yanz-GPT",
                    mimetype: "image/jpeg",
                  },
                  { quoted: msg },
                );
              } catch (error) {
                console.log("Error mengirim gambar:", error);
              }
            }
            client.sendMessage(from, { react: { text: "✅️", key: msg.key } });
          } catch (e) {
            console.log(e);
            //await client.sendMessage(from, { text: yanz.result, edit: key });
          }
        } else if (
          msg.text ||
          (msg.message.extendedTextMessage &&
            msg.message.extendedTextMessage.contextInfo?.quotedMessage
              ?.conversation)
        ) {
          const { key } = await client.sendMessage(
            from,
            { text: "```Sedang mencari jawaban...```" },
            { quoted: msg },
          );
          if (!msg.text) return;
          let model = "yanzgpt-revolution-25b-v3.0"; // model default
          let queryText = msg.text.replace(/\${botNumber.split('@')[0]}/g, "").trim();

          let qWords = queryText.split(/\s+/);
          if (qWords[0].toLowerCase() === "pro") {
            model = "yanzgpt-legacy-72b-v3.0";
            qWords.shift();
            queryText = qWords.join(" ");
          } else if (qWords[0].toLowerCase() === "default") {
            model = "yanzgpt-revolution-25b-v3.0";
            qWords.shift();
            queryText = qWords.join(" ");
          }
          if (
            msg.message.extendedTextMessage?.contextInfo?.quotedMessage
              ?.conversation
          ) {
            queryText = `${msg.message.extendedTextMessage.contextInfo.quotedMessage.conversation}\n\n${queryText}`;
          }

          console.log(
            "->[\x1b[1;32mNew\x1b[1;37m]",
            color("Question From", "yellow"),
            color(msg.pushName, "lightblue"),
            `: "${queryText}"`,
          );
          client.sendPresenceUpdate("composing", from);

          try {
            const big = await clover(
              queryText.replace(/\${botNumber.split('@')[0]}/g, "").trim(),
              model,
            );
            const ynz = big.choices[0].message.content
              .replace(/####/g, "")
              .replace(/###/g, "")
              .replace(/##/g, "")
              .replace(/\*\*/g, "*");
            await client.sendMessage(from, { text: ynz, edit: key });
            if (big.image) {
              try {
                //await client.sendMessage(from, { text: ynz, edit: key });
                const buffer = Buffer.from(big.image, "base64");
                await client.sendMessage(
                  from,
                  {
                    image: buffer,
                    caption: "Image From Yanz-GPT",
                    mimetype: "image/jpeg",
                  },
                  { quoted: msg },
                );
              } catch (error) {
                console.log("Error mengirim gambar:", error);
              }
            }
          } catch (e) {
            await client.sendMessage(from, {
              text: "Terjadi kesalahan",
              edit: key,
            });
          }
        }
      }
  }
};

//end module exports
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.red(`New ${__filename}`));
  delete require.cache[file];
  require(file);
});
